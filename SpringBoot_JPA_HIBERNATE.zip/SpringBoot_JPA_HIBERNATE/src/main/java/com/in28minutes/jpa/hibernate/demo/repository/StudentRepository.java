package com.in28minutes.jpa.hibernate.demo.repository;

import javax.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.in28minutes.jpa.hibernate.demo.entity.Course;
import com.in28minutes.jpa.hibernate.demo.entity.Passport;
import com.in28minutes.jpa.hibernate.demo.entity.Student;

@Repository
@Transactional
public class StudentRepository {
	
	private Logger logger= LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	EntityManager em;
	
	// finding the object with id
	public Student findById(Long id){
	return em.find(Student.class, id);
	}
	
	 public void deleteById(Long id){
		 Student student=findById(id);
		 em.remove(student);
	 }
	 public Student save(Student student){
		 if(student.getId()==null){
			 em.persist(student);
		 }
		 else{
			 em.merge(student);
		 }
		 return student;
	 }
	 public void savestudentwithPassport(){
		 Passport passport=new Passport("Z12345");
		 em.persist(passport);
		 
		 Student student=new Student("Mike");
		 student.setPassport(passport);
		 em.persist(student);

	 }
	 public void understandPersistence(){
			Student student=em.find(Student.class,20001L);
			Passport passport=student.getPassport();
			passport.setnumber("E12345");
			student.setName("Ranga-Ipdated");	
	 }
	 public void insertHardcodeVideos(){
		 Student student=new Student("Jack");
		 Course course= new Course("Microservices");
		 
		 em.persist(student);
		 em.persist(course);
		 
		 student.addCourse(course);
		 course.addStudent(student);
		 em.persist(student);
		 
	 }
	 public void insertNONHardcodeVideos(Student student,Course course){
		 student.addCourse(course);
		 course.addStudent(student);
		 
		 em.persist(student);
		 em.persist(course);
		 
		 
	 }

}
