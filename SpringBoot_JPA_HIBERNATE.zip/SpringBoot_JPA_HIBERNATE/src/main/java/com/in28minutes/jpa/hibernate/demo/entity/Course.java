package com.in28minutes.jpa.hibernate.demo.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.Where;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@SQLDelete(sql="update course set is_deleted=true where id=?")
@Where(clause="is_deleted=false")
public class Course {
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(nullable=false)
	private String name;
	
	@UpdateTimestamp
	private LocalDateTime lastUpdatedDate;
	
	@CreationTimestamp
	private LocalDateTime createdDate;
	
	@OneToMany(mappedBy="course")
	List<Review> review =new ArrayList();
	
	@ManyToMany(mappedBy="course")
	@JsonIgnore
	List<Student> student=new ArrayList();
	
	private boolean isDeleted;
	
	public List<Student> getStudent() {
		return student;
	}

	public void addStudent(Student student) {
		this.student.add(student) ;
	}

	public List<Review> getReview() {
		return review;
	}

	public void addReview(Review review) {
		this.review.add(review);
	}

	public void removeReview(Review review) {
		this.review.remove(review);
	}
	public Long getId() {
		return id;
	}
	
	public Course(){
		
	}
	@Override
	public String toString() {
		return String.format("Course[%s] Review[%s]",name,review);
	}
	public Course(String name)
	{
		this.name=name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
