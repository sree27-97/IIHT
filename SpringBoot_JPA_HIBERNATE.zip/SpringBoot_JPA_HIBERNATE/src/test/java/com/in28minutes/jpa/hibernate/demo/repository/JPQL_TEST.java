package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.jpa.hibernate.demo.DemoApplication;
import com.in28minutes.jpa.hibernate.demo.entity.Course;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=DemoApplication.class)
public class JPQL_TEST {
	private Logger logger= LoggerFactory.getLogger(this.getClass());
	@Autowired
	CourseRepository cr1;
	
	@Autowired
	EntityManager em;
	
	@Test
	
	public void jpql_courses_without_students(){
		TypedQuery query=em.createQuery("Select c from Course c where c.student is empty",Course.class);
		List<Course> resultlist=query.getResultList();
		logger.info("Results -> {}",resultlist);
	}
	
	

}
