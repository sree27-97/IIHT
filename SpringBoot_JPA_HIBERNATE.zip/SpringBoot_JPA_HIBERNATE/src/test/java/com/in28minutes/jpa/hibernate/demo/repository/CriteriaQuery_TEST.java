package com.in28minutes.jpa.hibernate.demo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.jpa.hibernate.demo.DemoApplication;
import com.in28minutes.jpa.hibernate.demo.entity.Course;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=DemoApplication.class)
public class CriteriaQuery_TEST {
	private Logger logger= LoggerFactory.getLogger(this.getClass());
	@Autowired
	CourseRepository cr1;
	
	@Autowired
	EntityManager em;
	
	@Test
	
	public void jpql_courses_without_students(){
		
		CriteriaBuilder cb=em.getCriteriaBuilder();
		CriteriaQuery<Course> cq= cb.createQuery(Course.class);
		Root<Course> courseroot=cq.from(Course.class);
		
		
		TypedQuery<Course> query=em.createQuery(cq.select(courseroot));
		List<Course> resultlist=query.getResultList();
		logger.info("select c from course c :: Results -> {}",resultlist);
	}
	
	

}
