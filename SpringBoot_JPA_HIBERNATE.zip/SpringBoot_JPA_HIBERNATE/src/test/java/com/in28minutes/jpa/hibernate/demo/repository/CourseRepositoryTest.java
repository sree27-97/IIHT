package com.in28minutes.jpa.hibernate.demo.repository;
import static org.junit.Assert.*;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.in28minutes.jpa.hibernate.demo.DemoApplication;
import com.in28minutes.jpa.hibernate.demo.entity.Course;
import com.in28minutes.jpa.hibernate.demo.entity.Review;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=DemoApplication.class)
public class CourseRepositoryTest {
	private Logger logger= LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	CourseRepository cr1;
	
	@Autowired
	EntityManager em;

	@Test
	public void findBYID_basic(){
		Course course=cr1.findById(10001L);
		assertEquals("JPA in 50 steps",course.getName());
		
	}
	
	@Test
	@DirtiesContext
	public void deleteById(){
	cr1.deleteById(10002L);
	assertNull(cr1.findById(10002L));
	}
	
	/*@Test
	public void findBYID_firstlevel_cache(){
		Course course=cr1.findById(1000L);
		logger.info("First course retrieved -> {}",course);
		Course course1=cr1.findById(1000L);
		logger.info("First course retrieved again-> {}",course1);
		assertEquals("JPA in 50 steps",course.getName());
		assertEquals("JPA in 50 steps",course1.getName());
		
	}*/
	
	@Test
	@Transactional
	public void retreivereviewsforcourse(){
		Course course=cr1.findById(10003L);
		logger.info("reviews are ->{}",course.getReview());
		
	}
	@Test
	@Transactional
	public void retreivecourseforreview(){
		Review review=em.find(Review.class,50001L);
		logger.info("courses are are ->{}",review.getCourse());
		
	}
}
